BEGIN TRANSACTION;
CREATE TABLE accounts (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	password_changed_at DATETIME, 
	email VARCHAR(255) NOT NULL, 
	email_source VARCHAR(16) DEFAULT '' NOT NULL, 
	provider_email VARCHAR(255) DEFAULT '' NOT NULL, 
	provider_email_off VARCHAR(255) DEFAULT '' NOT NULL, 
	language VARCHAR(16) NOT NULL, 
	browser_language VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	blocked_at DATETIME, 
	deleted_at DATETIME, 
	password_reset_notice BOOLEAN DEFAULT 0 NOT NULL, 
	storage_limit INTEGER, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	color INTEGER, 
	preferences JSON, 
	device_key VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "accounts" VALUES(1,'betrieb','Betrieb Beispiel','0.4.0','operator','password','$argon2id$v=19$m=1024,t=1,p=1$N0tt6CpA/0nzCN33oxBUHg$YgVfIr1Pn1dRfvqZAGLC/sbIZTL+mZs3wlYUlh16kDI','2026-11-24 19:25:22.537459','betrieb@example.com','','','','de','','2026-11-24 19:25:22.538725','2026-11-24 19:25:24.192795',0,NULL,NULL,NULL,0,NULL,'07df1dd39e899956bb06928a940ba4ad0c8612749886a29840288c18c3b2a7efb0c670d5162c8d472b623532de7a2c123047e36824d849e133c40e0e','["e040b90f1e0f5c706886877aa3abb811d78a0fed0aa381fe13952b4c77cfe777", "381c34dec6252f79f06ea8273d17c4a85a2e6c0aa595192f48907ddc7a4ec97e", "225ab459f55927a79fcc600d3058e82eecad2cffdcc18e61a5f22f98164eda50", "2a5e403781cdb5812b9ed9586433420a055d672589e66ab4ea80e4a6da81f367", "2a4c4f2d20dc84e7e03149166c3883a75a2048d3697adce34271df46602790a5", "379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f"]',59851610,NULL,NULL,0,NULL,'c2bGZcau1cwf7bvCoilBQ40aA6J9y4Ir');
INSERT INTO "accounts" VALUES(2,'erika-muster','Erika Muster','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$q/jyvZlRu1DI8uVf3LZkBw$GcXRuiPIUYv4PF7cRyDbxr+EPhlv+czrljYr4mlLfW0','2026-11-24 19:25:22.737631','','','','','','','2026-11-24 19:25:22.737929','2026-11-24 19:25:22.741834',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,1,NULL,'AOodVGpgpKVdk7zbK1bhMkXLpd9TkrVT');
INSERT INTO "accounts" VALUES(3,'jonas','Jonas Beispiel','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$YiZN+T9bt3W2495a3nkwsw$H2TUHWE2BOAhz8PaU9jaTAupO33gwhG8MbhFfzQcdJ8','2026-11-24 19:25:22.822376','jonas@example.net','','','','','','2026-11-24 19:25:22.823253','2026-11-24 19:25:22.827912',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,2,NULL,'5G97WUml1omL9Dd_Ua4LN6Xa8zYlHGvb');
INSERT INTO "accounts" VALUES(4,'kim','Kim','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$CH1MiTIFWdIhhs9tawKwXw$lnIf9Ttg+Q/THa7+DKjdVdrdcGO41zigd5r7eGFQlCY','2026-11-24 19:25:23.177363','familie@example.net','','','','','','2026-11-24 19:25:23.177650','2026-11-24 19:25:23.181897',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,NULL,'-RU4LuHVS6R0sz0XJXlUovwqjftuFGtM');
INSERT INTO "accounts" VALUES(5,'lou','Lou','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$oqqEH1OxVRk0RmzJuD7MzA$ZbJRR+ghjD9/pmFLdz367QXyAWeuc0qg0n9Jh1Ys5tA','2026-11-24 19:25:23.224062','Familie@Example.net','','','','','','2026-11-24 19:25:23.224347','2026-11-24 19:25:23.228314',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,NULL,'eOOluZ4YsqM9KovvXudgwjhpmXuMhS1L');
INSERT INTO "accounts" VALUES(6,'mona','Mona Beispiel','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$PjfRgh1wHxjkLbVXWrQ5bA$1YEA57MRCDjBJtkq6uYBZdpeP7Wfg6JXnnzIuBKV4xw','2026-11-24 19:25:23.338556','mona@example.com','','','','','','2026-11-24 19:25:23.339345','2026-11-24 19:25:23.433818',0,NULL,NULL,NULL,0,NULL,'3d215f63b1a86de99a546e8a1979d631c168a3114dfcbadf841ec0426647d8774d0420159cfe3741e5544efe7f913822cbbaf62b4541589342b3f235','["379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f", "91503f89b9a82e4c4c2dd5e14b70d9698529b148052db310d6dc513803f4e030", "52fcd1c9b617d04b46a992a0fe60ee6aa8365fff9037b7277ff6f461c82d61fc", "c27df958ff66399116260b6f53cf835077230f2a9036932ec7494094354e17dc", "0ad944c86a387c84c69a42105d24b4516494ac6fb0f64160702ad8240f194516", "88d0b34c8c162d779531f81303be88bef29b09d651dbc916899f90e887b3536a"]',59851610,NULL,NULL,NULL,NULL,'n2a-3edfQnjyemf7Ga1WR4Rm7hqtzFHb');
INSERT INTO "accounts" VALUES(7,'sam','Sam','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$0AhU4vZ/3DTtTkqzim9o/w$liyrKHYSzYPly7Fy5INdWODelB/OTMGJmQx5AdS9xpw','2026-11-24 19:25:23.652374','sam@example.org','provider','','','','','2026-11-24 19:25:23.652676','2026-11-24 19:25:23.682373',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,3,NULL,'3VnwAqsNelClMrZ177O9hHqdsd4RjGQO');
INSERT INTO "accounts" VALUES(8,'robin.sso','','0.4.0','operator','oidc','',NULL,'robin@sso.example.com','provider','','','','','2026-11-24 19:25:23.953820','2026-11-24 19:25:23.963669',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,4,NULL,'8StGku2dfsekUVYxOumhCAsEz2MlH-z7');
INSERT INTO "accounts" VALUES(9,'gesperrt','Gesperrt Beispiel','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$JOJ8LHm2pML3qhZwbFXRig$pej7qhq/Wso/umQ0GsDuKa62SPLc99qW95jW9BwE3PE','2026-11-24 19:25:24.024827','gesperrt@example.com','','','','','','2026-11-24 19:25:24.025115','2026-11-24 19:25:24.028922',0,NULL,'2026-11-24 19:25:24.107166',NULL,0,NULL,'','',0,NULL,NULL,NULL,NULL,'nML65p339L02YnARcSdOkY_-Q-Q_C1l3');
INSERT INTO "accounts" VALUES(10,'weg','Weg Beispiel','0.4.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$u/8ASnKGIOad/FWlH7HFYw$x7DRXEJ6cMrIa67lbEhuVyFjRGr878KM60T7YRRi2mU','2026-11-24 19:25:24.070857','weg@example.com','','','','','','2026-11-24 19:25:24.071141','2026-11-24 19:25:24.074865',0,NULL,NULL,'2026-11-24 19:25:24.141481',0,NULL,'','',0,NULL,NULL,NULL,NULL,'f8vHiaAduoowjxdwyj9zJzM2h-SxmNAc');
CREATE TABLE api_keys (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	allow_mcp BOOLEAN DEFAULT 0 NOT NULL, 
	calendar_ids JSON, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	client_ref VARCHAR(64), 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, client_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_keys" VALUES(1,3,'Dashboard','read',0,NULL,'fd32c74117e2aebffda7c016026fb337faf2943f28f1560e9bfde82aef1c2125','nt_api_best',NULL,'2026-11-24 19:25:22.960847',NULL,NULL);
CREATE TABLE app_codes (
	code_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	state VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE app_devices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	via_id INTEGER, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	push_ticket TEXT DEFAULT '' NOT NULL, 
	push_key VARCHAR(100) DEFAULT '' NOT NULL, 
	push_alerts BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "app_devices" VALUES(1,6,'iPhone (Bestand)','ios','db4ed26f96e37ce26d0bd4d186a91234fc4acc022783338c69e0e0b92d76f5fa',NULL,'2026-11-24 19:25:23.606798',NULL,'','',0);
CREATE TABLE app_gone_devices (
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash)
);
CREATE TABLE app_ops (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	ref VARCHAR(64) NOT NULL, 
	op VARCHAR(16) NOT NULL, 
	answer JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE app_pairings (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	secret_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "app_pairings" VALUES('bestand-kopplung-mona-22',6,'7d36b460221b5a94e9ae2fdb29392aaae5828b7ba205eb75747d4004deab5146','2026-11-24 19:25:23.540990','2026-11-24 19:35:23.540990','2026-11-24 19:25:23.598601',1);
CREATE TABLE attachments (
	id VARCHAR(32) NOT NULL, 
	event_id INTEGER, 
	uploaded_by INTEGER, 
	pending_ref VARCHAR(64) DEFAULT '' NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	name TEXT NOT NULL, 
	mime VARCHAR(100) NOT NULL, 
	size INTEGER NOT NULL, 
	stored INTEGER NOT NULL, 
	width INTEGER, 
	height INTEGER, 
	pages INTEGER, 
	has_view BOOLEAN NOT NULL, 
	has_thumb BOOLEAN NOT NULL, 
	inline BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(event_id) REFERENCES events (id) ON DELETE CASCADE, 
	FOREIGN KEY(uploaded_by) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	provider_checked BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'b422c14c9ef3e4681ba443b1a39312b292af87fa08337d91d44302ab157949e9',1,'2026-11-24 19:25:22.553505','2026-12-24 19:25:22.547241','2026-11-24 19:25:22.553508','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(2,'367c590bb0c34f6af42b4dd52f1fdded0b747d12de544bd6459f63f6349138c5',2,'2026-11-24 19:25:22.745343','2026-12-24 19:25:22.741660','2026-11-24 19:25:22.745346','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(3,'fcf32653b0288d2ea7a8aa2be37d3bac1cc8d3c2b082f7cbb93f96c6f2e95bf3',3,'2026-11-24 19:25:22.830976','2026-12-24 19:25:22.827752','2026-11-24 19:25:22.830979','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(4,'76e1a6f99293a164fd79d8c916b918dd9565003bf9e406c567acd9dcb33159e8',4,'2026-11-24 19:25:23.184754','2026-12-24 19:25:23.181823','2026-11-24 19:25:23.184757','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(5,'78d0593875fd6d7b5cbf70d87fdd33df035d288b6a302f44407f484494439a2d',5,'2026-11-24 19:25:23.231611','2026-12-24 19:25:23.228243','2026-11-24 19:25:23.231614','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(6,'070402082678478511f20c66fea261747198af2d66c11a642e43781677475a11',6,'2026-11-24 19:25:23.352156','2026-12-24 19:25:23.345296','2026-11-24 19:25:23.352163','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(7,'4627ba05cd74a1dc21fb2fbb90bdab4b5796714b07bf3d56ce8137fb28c9e82b',7,'2026-11-24 19:25:23.658853','2026-12-24 19:25:23.656464','2026-11-24 19:25:23.658856','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(8,'748869e188c96f5c4e359120b48c91d8757ec6242e0252ef1106218266f7dbf5',8,'2026-11-24 19:25:23.963992','2026-12-24 19:25:23.963610','2026-11-24 19:25:23.963994','testclient','testclient',1);
INSERT INTO "auth_sessions" VALUES(9,'322e8eaac604e9e0c19e343a990e59d90e8b550beb641805f54d8d861199c4fc',9,'2026-11-24 19:25:24.031548','2026-12-24 19:25:24.028811','2026-11-24 19:25:24.031551','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(10,'5f34edf18321ac0c2d97c0a9ddd296aca7a0cde4c72378ba90df58a86b16f70a',10,'2026-11-24 19:25:24.077419','2026-12-24 19:25:24.074752','2026-11-24 19:25:24.077422','testclient','testclient',0);
CREATE TABLE calendar_moves (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	source_calendar_id INTEGER, 
	target_id INTEGER, 
	client_ref VARCHAR(64) NOT NULL, 
	result JSON, 
	state VARCHAR(8) DEFAULT 'done' NOT NULL, 
	done INTEGER DEFAULT '0' NOT NULL, 
	total INTEGER DEFAULT '0' NOT NULL, 
	staging_id INTEGER, 
	problem VARCHAR(64) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, client_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(source_calendar_id) REFERENCES calendars (id) ON DELETE SET NULL, 
	FOREIGN KEY(target_id) REFERENCES calendars (id) ON DELETE SET NULL
);
CREATE TABLE calendar_prefs (
	account_id INTEGER NOT NULL, 
	default_calendar_id INTEGER, 
	seeded BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(default_calendar_id) REFERENCES calendars (id) ON DELETE SET NULL
);
INSERT INTO "calendar_prefs" VALUES(3,1,1);
CREATE TABLE calendar_settings (
	account_id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	hidden BOOLEAN DEFAULT 0 NOT NULL, 
	position INTEGER DEFAULT '0' NOT NULL, 
	notify BOOLEAN DEFAULT 0 NOT NULL, 
	reminder_default VARCHAR(16) DEFAULT '' NOT NULL, 
	new_defaults JSON, 
	highlight BOOLEAN, 
	PRIMARY KEY (account_id, calendar_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE
);
INSERT INTO "calendar_settings" VALUES(3,1,0,0,0,'',NULL,NULL);
CREATE TABLE calendar_shares (
	calendar_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	"right" VARCHAR(8) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (calendar_id, account_id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE calendars (
	id INTEGER NOT NULL, 
	owner_id INTEGER NOT NULL, 
	dav_name VARCHAR(128) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	icon VARCHAR(32) DEFAULT '' NOT NULL, 
	background BOOLEAN DEFAULT 0 NOT NULL, 
	reminder INTEGER DEFAULT '0' NOT NULL, 
	client_ref VARCHAR(64), 
	props_rev INTEGER DEFAULT '0' NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	deleted_at DATETIME, 
	deleted_by INTEGER, 
	trash_until DATETIME, 
	deleted_by_name VARCHAR(80) DEFAULT '' NOT NULL, 
	orphan BOOLEAN DEFAULT 0 NOT NULL, 
	staging BOOLEAN DEFAULT 0 NOT NULL, 
	source_id INTEGER, 
	remote_url VARCHAR(1000) DEFAULT '' NOT NULL, 
	read_only BOOLEAN DEFAULT 0 NOT NULL, 
	locked BOOLEAN DEFAULT 0 NOT NULL, 
	sync_token TEXT DEFAULT '' NOT NULL, 
	ctag VARCHAR(255) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (owner_id, client_ref), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (dav_name), 
	FOREIGN KEY(deleted_by) REFERENCES accounts (id) ON DELETE SET NULL, 
	FOREIGN KEY(source_id) REFERENCES sources (id) ON DELETE CASCADE
);
INSERT INTO "calendars" VALUES(1,3,'bestand-kalender-1','Personal','slate','',0,0,NULL,0,'2026-11-24 19:25:23.058369','2026-11-24 19:25:23.058373',NULL,NULL,NULL,'',0,0,NULL,'',0,0,'','');
CREATE TABLE collection_calendars (
	collection_id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	PRIMARY KEY (collection_id, calendar_id), 
	FOREIGN KEY(collection_id) REFERENCES collections (id) ON DELETE CASCADE, 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE
);
CREATE TABLE collections (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	client_ref VARCHAR(64), 
	with_tasks BOOLEAN DEFAULT '0' NOT NULL, 
	task_areas TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, client_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE device_setups (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	device_id INTEGER, 
	password_enc TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(device_id) REFERENCES devices (id) ON DELETE CASCADE
);
INSERT INTO "device_setups" VALUES(1,'a15603d35e83f3868e206b08efeecdbd38a2ab2caa877ccef13c7530766f66bb',3,1,'','2026-11-24 19:25:22.985173','2026-11-24 19:35:22.984563','2026-11-24 19:25:23.043673');
INSERT INTO "device_setups" VALUES(2,'cf552816bca064c234db9dd0b51e9f281886ec377030e78f21e2f7716bb31d6a',3,2,'','2026-11-24 19:25:23.017151','2026-11-24 19:35:23.016958','2026-11-24 19:25:23.134424');
CREATE TABLE devices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	password_hash VARCHAR(64) NOT NULL, 
	client VARCHAR(80) NOT NULL, 
	platform VARCHAR(8) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	app_device_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (password_hash)
);
INSERT INTO "devices" VALUES(1,3,'iPhone Kalender','d07b2fd70f487b3b1da8d91feb22663515deb811dcbf06fa0ff18d96d317d2c8','testclient','','2026-11-24 19:25:22.984049','2026-11-24 19:25:23.042679',NULL);
INSERT INTO "devices" VALUES(2,3,'Thunderbird','e0463a9b0e2a669582de90b8e44a31611eda2f9fdbb1419f531bfbc934cc3c9f','testclient','','2026-11-24 19:25:23.016341','2026-11-24 19:25:23.134132',NULL);
CREATE TABLE event_changes (
	id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	href VARCHAR(255) NOT NULL, 
	deleted BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE
);
INSERT INTO "event_changes" VALUES(1,1,'bestand-termin.ics',0,'2026-11-24 19:25:23.112613');
CREATE TABLE event_conflicts (
	id INTEGER NOT NULL, 
	event_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	by_id INTEGER, 
	mine_ical TEXT NOT NULL, 
	theirs_etag VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(event_id) REFERENCES events (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(by_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE events (
	id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	uid VARCHAR(255) NOT NULL, 
	href VARCHAR(255) NOT NULL, 
	ical TEXT NOT NULL, 
	etag VARCHAR(64) NOT NULL, 
	title TEXT NOT NULL, 
	starts_at DATETIME NOT NULL, 
	ends_at DATETIME, 
	all_day BOOLEAN DEFAULT 0 NOT NULL, 
	time_zone VARCHAR(64) NOT NULL, 
	recurring BOOLEAN DEFAULT 0 NOT NULL, 
	busy BOOLEAN NOT NULL, 
	location TEXT NOT NULL, 
	size INTEGER NOT NULL, 
	created_by INTEGER, 
	updated_by INTEGER, 
	client_ref VARCHAR(64), 
	prev_etag VARCHAR(64) DEFAULT '' NOT NULL, 
	prev_ical TEXT DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	deleted_at DATETIME, 
	deleted_by INTEGER, 
	trash_until DATETIME, 
	deleted_by_name VARCHAR(80) DEFAULT '' NOT NULL, 
	search_text TEXT, 
	remote_etag VARCHAR(255) DEFAULT '' NOT NULL, 
	remote_of INTEGER DEFAULT '0' NOT NULL, 
	waiting BOOLEAN DEFAULT 0 NOT NULL, 
	alarm_leads JSON, 
	alarm_lead_max INTEGER, 
	updated_via VARCHAR(100) DEFAULT '' NOT NULL, 
	deleted_via VARCHAR(100) DEFAULT '' NOT NULL, 
	origin VARCHAR(16) DEFAULT '' NOT NULL, 
	origin_address VARCHAR(320) DEFAULT '' NOT NULL, 
	origin_sequence INTEGER DEFAULT '0' NOT NULL, 
	deleted_reason VARCHAR(32) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL, 
	FOREIGN KEY(updated_by) REFERENCES accounts (id) ON DELETE SET NULL, 
	FOREIGN KEY(deleted_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "events" VALUES(1,1,'bestand-termin@example.com','bestand-termin.ics','BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Apple Inc.//iPhone OS 18.1//EN
BEGIN:VEVENT
UID:bestand-termin@example.com
DTSTAMP:20261126T150000Z
DTSTART:20261201T090000Z
DTEND:20261201T100000Z
SUMMARY:Bestand Termin
END:VEVENT
END:VCALENDAR
','"7df146648f5d9e6d6ab45c710bab5c30"','Bestand Termin','2026-12-01 09:00:00.000000','2026-12-01 10:00:00.000000',0,'UTC',0,1,'',245,3,3,NULL,'','','2026-11-24 19:25:23.111730','2026-11-24 19:25:23.107875',NULL,NULL,NULL,'','bestand termin','',0,0,'[]',NULL,'','','','',0,'');
CREATE TABLE guest_links (
	id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	token_enc TEXT NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME, 
	expires_on VARCHAR(10) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (calendar_id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE, 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE imports (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	summary JSON, 
	state VARCHAR(8) NOT NULL, 
	calendar_id INTEGER, 
	result JSON, 
	done INTEGER DEFAULT '0' NOT NULL, 
	total INTEGER DEFAULT '0' NOT NULL, 
	staging_id INTEGER, 
	problem VARCHAR(64) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE SET NULL
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'492869556545b7521f6e63bde2eb0011b0abe092780c44eec752cf56bd2d41a2','member','gast@example.org',1,'2026-11-24 19:25:24.169135','2026-12-24 19:25:24.168923');
CREATE TABLE nexpaper_connections (
	account_id INTEGER NOT NULL, 
	url VARCHAR(500) NOT NULL, 
	token_sealed TEXT NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	version VARCHAR(32) DEFAULT '' NOT NULL, 
	hidden BOOLEAN DEFAULT 0 NOT NULL, 
	problem VARCHAR(64) DEFAULT '' NOT NULL, 
	checked_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE nextasks_connections (
	account_id INTEGER NOT NULL, 
	url VARCHAR(500) NOT NULL, 
	token_sealed TEXT NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	time_zone VARCHAR(64) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	hidden BOOLEAN DEFAULT 0 NOT NULL, 
	areas_off TEXT DEFAULT '' NOT NULL, 
	task_choice TEXT DEFAULT '' NOT NULL, 
	areas_hidden TEXT DEFAULT '' NOT NULL, 
	problem VARCHAR(64) DEFAULT '' NOT NULL, 
	checked_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_changes (
	id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	event_id INTEGER NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	actors JSON NOT NULL, 
	first_at DATETIME NOT NULL, 
	last_at DATETIME NOT NULL, 
	before_start DATETIME, 
	title TEXT NOT NULL, 
	starts_at DATETIME NOT NULL, 
	all_day BOOLEAN NOT NULL, 
	recurring BOOLEAN NOT NULL, 
	busy BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (calendar_id, event_id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE
);
CREATE TABLE notify_outbox (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(12) DEFAULT 'change' NOT NULL, 
	target_id INTEGER NOT NULL, 
	calendar_id INTEGER, 
	payload JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	next_try_at DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	sent_at DATETIME, 
	failed_at DATETIME, 
	last_error VARCHAR(40) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'bestand-sam',7,'https://sso.example.com','sam@example.org','2026-11-24 19:25:23.777734',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'bestand-robin',8,'https://sso.example.com','robin@sso.example.com','2026-11-24 19:25:23.955635',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nextime-bestand','960ceaec97d3dba941dd43f0b62dd7d16f1a748bce0f8ca7027a1ff4cf0a6b10f6611c6015e11cacc265','openid profile email',1,0,1,'',0,'','','2026-11-24 19:25:22.677866');
CREATE TABLE password_resets (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "password_resets" VALUES(1,'35a810f62cd0c0adc80a5000327ab2afe188dfb8b39aa379b618ce1fc96779b4',2,1,'2026-11-24 19:25:24.198635','2026-12-24 19:25:24.197987');
CREATE TABLE reminder_choices (
	event_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	minutes JSON NOT NULL, 
	alarms TEXT DEFAULT '' NOT NULL, 
	occurrences JSON, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (event_id, account_id), 
	FOREIGN KEY(event_id) REFERENCES events (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE reminder_log (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	event_id INTEGER NOT NULL, 
	occurrence VARCHAR(32) NOT NULL, 
	minutes INTEGER NOT NULL, 
	fire_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, event_id, occurrence, minutes), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE remote_changes (
	id INTEGER NOT NULL, 
	calendar_id INTEGER NOT NULL, 
	href VARCHAR(255) NOT NULL, 
	op VARCHAR(8) NOT NULL, 
	remote_etag VARCHAR(255) NOT NULL, 
	answer VARCHAR(16) NOT NULL, 
	occurrence VARCHAR(20) NOT NULL, 
	attempts INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE CASCADE
);
CREATE TABLE remote_notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	calendar_id INTEGER, 
	title TEXT NOT NULL, 
	lost_ical TEXT NOT NULL, 
	source_kind VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE SET NULL
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('running_version','"0.4.0"');
INSERT INTO "settings" VALUES('webpush_key_enc','"0d17e4577b248629371a0767b144bc14d4ef332952e76033cb636a5f32caa196d23647c847e49a8243afc5d357a086fa2be6c99d6135c14477e101bfe72f4a9f772187c7bc0d4589000b5d6b7e5960fb06f01ba986983160fa04b33d355f0df4a19c991bd0ca389390b6ff86633bee9dfc7f1879e870c5f83f4e83c5862b105eb3b5aed11994cd805c0ac45c7c1207179496b7c113c52b4c2b555e997cf943b8f344036063ff7e9f58a0067f69eec046f3c78c2cfac8dc18f22b82441bcddf0295425c53a4812c8b9d4157085ac76d25d8ce6815c71cd079f09517b7cd2f0686b8fc346ed3214887a939efd2d034e253c5a30ba5610f22edabe97cef6f7fb1ba178323860cdf3d3e7e0dda6e31"');
INSERT INTO "settings" VALUES('public_url','"https://kalender.example.com"');
INSERT INTO "settings" VALUES('sync_epoch','"e55cdda6"');
CREATE TABLE share_notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	calendar_id INTEGER, 
	owner_id INTEGER, 
	calendar_name TEXT NOT NULL, 
	owner_name VARCHAR(80) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(calendar_id) REFERENCES calendars (id) ON DELETE SET NULL, 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE sources (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	label VARCHAR(500) NOT NULL, 
	identity VARCHAR(64) NOT NULL, 
	server VARCHAR(1000) NOT NULL, 
	username VARCHAR(320) NOT NULL, 
	secret_enc TEXT NOT NULL, 
	client_ref VARCHAR(64), 
	state VARCHAR(16) NOT NULL, 
	state_since DATETIME, 
	problem VARCHAR(64) NOT NULL, 
	synced_at DATETIME, 
	due_at DATETIME, 
	failures INTEGER NOT NULL, 
	remote JSON, 
	options JSON, 
	addresses JSON, 
	schedules BOOLEAN DEFAULT 0 NOT NULL, 
	loading BOOLEAN DEFAULT 0 NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, kind, identity), 
	UNIQUE (account_id, client_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE task_ticks (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	task_id VARCHAR(100) NOT NULL, 
	ref VARCHAR(64) NOT NULL, 
	done BOOLEAN NOT NULL, 
	state VARCHAR(8) NOT NULL, 
	tries INTEGER DEFAULT '0' NOT NULL, 
	next_at DATETIME, 
	title VARCHAR(300) NOT NULL, 
	copy_id VARCHAR(100) DEFAULT '' NOT NULL, 
	due_before VARCHAR(10) DEFAULT '' NOT NULL, 
	time_before VARCHAR(5) DEFAULT '' NOT NULL, 
	problem VARCHAR(64) DEFAULT '' NOT NULL, 
	seen BOOLEAN DEFAULT 0 NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE trashed_parts (
	id INTEGER NOT NULL, 
	event_id INTEGER NOT NULL, 
	kind VARCHAR(12) NOT NULL, 
	occurrence VARCHAR(20) NOT NULL, 
	title TEXT NOT NULL, 
	starts_at DATETIME NOT NULL, 
	all_day BOOLEAN NOT NULL, 
	time_zone VARCHAR(64) NOT NULL, 
	removed TEXT DEFAULT '' NOT NULL, 
	"before" TEXT DEFAULT '' NOT NULL, 
	etag_after VARCHAR(64) DEFAULT '' NOT NULL, 
	exceptions BOOLEAN DEFAULT 0 NOT NULL, 
	deleted_at DATETIME NOT NULL, 
	deleted_by INTEGER, 
	deleted_by_name VARCHAR(80) DEFAULT '' NOT NULL, 
	trash_until DATETIME, 
	deleted_via VARCHAR(100) DEFAULT '' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(event_id) REFERENCES events (id) ON DELETE CASCADE, 
	FOREIGN KEY(deleted_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE used_marks (
	digest VARCHAR(64) NOT NULL, 
	used_at DATETIME NOT NULL, 
	PRIMARY KEY (digest)
);
CREATE TABLE webpush_subscriptions (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	endpoint TEXT NOT NULL, 
	p256dh VARCHAR(100) NOT NULL, 
	auth VARCHAR(40) NOT NULL, 
	user_agent VARCHAR(300) NOT NULL, 
	installed BOOLEAN DEFAULT 0 NOT NULL, 
	reminders BOOLEAN DEFAULT 1 NOT NULL, 
	platform VARCHAR(8) DEFAULT '' NOT NULL, 
	"key" VARCHAR(32) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES auth_sessions (id) ON DELETE CASCADE, 
	UNIQUE (endpoint)
);
CREATE INDEX ix_used_marks_used_at ON used_marks (used_at);
CREATE INDEX ix_app_gone_devices_account_id ON app_gone_devices (account_id);
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_password_resets_account_id ON password_resets (account_id);
CREATE INDEX ix_sources_account_id ON sources (account_id);
CREATE INDEX ix_collections_account_id ON collections (account_id);
CREATE INDEX ix_devices_account_id ON devices (account_id);
CREATE INDEX ix_devices_app_device_id ON devices (app_device_id);
CREATE INDEX ix_notify_outbox_due ON notify_outbox (sent_at, failed_at, next_try_at);
CREATE INDEX ix_notify_outbox_account_id ON notify_outbox (account_id);
CREATE INDEX ix_reminder_log_fire_at ON reminder_log (fire_at);
CREATE INDEX ix_reminder_log_account_id ON reminder_log (account_id);
CREATE INDEX ix_api_keys_account_id ON api_keys (account_id);
CREATE INDEX ix_task_ticks_task_id ON task_ticks (task_id);
CREATE INDEX ix_task_ticks_account_id ON task_ticks (account_id);
CREATE INDEX ix_app_devices_account_id ON app_devices (account_id);
CREATE INDEX ix_app_pairings_account_id ON app_pairings (account_id);
CREATE INDEX ix_app_codes_account_id ON app_codes (account_id);
CREATE INDEX ix_app_ops_created_at ON app_ops (created_at);
CREATE INDEX ix_app_ops_account_id ON app_ops (account_id);
CREATE INDEX ix_calendars_owner_id ON calendars (owner_id);
CREATE INDEX ix_calendars_source_id ON calendars (source_id);
CREATE INDEX ix_device_setups_account_id ON device_setups (account_id);
CREATE INDEX ix_webpush_subscriptions_session_id ON webpush_subscriptions (session_id);
CREATE INDEX ix_webpush_subscriptions_account_id ON webpush_subscriptions (account_id);
CREATE INDEX ix_remote_changes_calendar_id ON remote_changes (calendar_id);
CREATE INDEX ix_remote_notices_account_id ON remote_notices (account_id);
CREATE INDEX ix_calendar_shares_account_id ON calendar_shares (account_id);
CREATE INDEX ix_share_notices_account_id ON share_notices (account_id);
CREATE INDEX ix_share_notices_calendar_id ON share_notices (calendar_id);
CREATE INDEX ix_collection_calendars_calendar_id ON collection_calendars (calendar_id);
CREATE UNIQUE INDEX ix_events_client_ref ON events (created_by, client_ref) WHERE client_ref IS NOT NULL;
CREATE INDEX ix_events_ends_at ON events (ends_at);
CREATE INDEX ix_events_starts_at ON events (starts_at);
CREATE INDEX ix_events_uid ON events (uid);
CREATE INDEX ix_events_calendar_id ON events (calendar_id);
CREATE UNIQUE INDEX ix_events_live_href ON events (calendar_id, href) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX ix_events_live_uid ON events (calendar_id, uid) WHERE deleted_at IS NULL;
CREATE INDEX ix_event_changes_calendar_id ON event_changes (calendar_id);
CREATE INDEX ix_notify_changes_last_at ON notify_changes (last_at);
CREATE INDEX ix_notify_changes_calendar_id ON notify_changes (calendar_id);
CREATE INDEX ix_imports_account_id ON imports (account_id);
CREATE INDEX ix_calendar_moves_source_calendar_id ON calendar_moves (source_calendar_id);
CREATE INDEX ix_calendar_moves_account_id ON calendar_moves (account_id);
CREATE INDEX ix_trashed_parts_event_id ON trashed_parts (event_id);
CREATE INDEX ix_event_conflicts_account_id ON event_conflicts (account_id);
CREATE INDEX ix_event_conflicts_event_id ON event_conflicts (event_id);
CREATE INDEX ix_reminder_choices_account_id ON reminder_choices (account_id);
CREATE INDEX ix_attachments_uploaded_by ON attachments (uploaded_by);
CREATE INDEX ix_attachments_event_id ON attachments (event_id);
COMMIT;
